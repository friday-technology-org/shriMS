<!DOCTYPE html>
<html class="scroll-smooth overflow-x-hidden" lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'LaraCMS Dashboard')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0">
    <link rel="icon" href="{{ asset('assets/images/icons/icon-favicon.svg') }}" type="image/x-icon" sizes="16x16">
    <link rel="stylesheet" href="{{ asset('assets/styles/tailwind.min.css') }}?v=5.0">
    <link rel="stylesheet" href="{{ asset('assets/styles/style.min.css') }}?v=5.0">
    <link rel="stylesheet" href="{{ asset('assets/styles/cms-admin-extra.css') }}?v=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Chivo:wght@400;700;900&family=Noto+Sans:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css">
    <script src="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
  </head>
  <body class="w-screen relative overflow-x-hidden min-h-screen bg-gray-100 scrollbar-hide cms-dashboard-page dark:bg-[#000]">
    <div class="wrapper mx-auto text-gray-900 font-normal grid scrollbar-hide grid-cols-[257px,1fr] grid-rows-[auto,1fr]" id="layout">
      @include('cms-core::layouts.partials.sidebar')
      @include('cms-core::layouts.partials.header')
      <main class="overflow-x-scroll scrollbar-hide flex flex-col justify-between pt-[42px] px-[23px] pb-[28px]">
        @yield('content')
      </main>
    </div>

    {{-- Global Media Picker Modal --}}
    @include('cms-core::layouts.partials.media-picker-modal')
    
    <!-- Scripts -->
    <script src="{{ asset('assets/scripts/vendors/jquery-3.6.0.min.js') }}"></script>
    <script src="{{ asset('assets/scripts/chart-utils.min.js') }}"></script>
    <script src="{{ asset('assets/scripts/chart.min.js') }}"></script>
    <script src="{{ asset('assets/scripts/app.js') }}?v=5.0"></script>
    @stack('scripts')
  </body>
</html>