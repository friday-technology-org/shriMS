@extends('cms-core::install.layout')

@section('content')
<div class="text-center py-6 space-y-6">
  <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 text-4xl mb-2 shadow-inner border border-emerald-200 dark:border-emerald-800">
    🎉
  </div>

  <h2 class="text-2xl font-bold text-gray-900 dark:text-white">Installation Successfully Completed!</h2>

  <p class="text-gray-500 dark:text-gray-400 text-sm max-w-md mx-auto leading-relaxed">
    LaraCMS has been successfully installed. Database migrations have been executed, default options seeded, and your Super Administrator account has been configured.
  </p>

  <div class="bg-[#F8FAFC] dark:bg-[#0D1536] p-5 rounded-xl max-w-md mx-auto text-left text-xs text-gray-600 dark:text-gray-400 border border-[#E8EDF2] dark:border-[#1B254B] space-y-2.5">
    <div class="flex justify-between items-center">
      <span class="font-bold uppercase tracking-wider text-gray-500">Site Title:</span>
      <span class="text-gray-900 dark:text-white font-bold text-sm">{{ cms_option('site_title', 'LaraCMS') }}</span>
    </div>
    <div class="flex justify-between items-center">
      <span class="font-bold uppercase tracking-wider text-gray-500">Version:</span>
      <span class="text-gray-900 dark:text-white font-bold">1.0.0</span>
    </div>
    <div class="flex justify-between items-center">
      <span class="font-bold uppercase tracking-wider text-gray-500">Security Lock:</span>
      <span class="text-emerald-600 dark:text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900">
        Active (`storage/app/.installed`)
      </span>
    </div>
  </div>

  <div class="pt-4">
    <a href="{{ url('/') }}" class="btn normal-case h-fit min-h-fit transition-all duration-300 border-4 bg-color-brands hover:bg-color-brands hover:border-[#B2A7FF] dark:hover:border-[#B2A7FF] border-neutral-bg dark:border-dark-neutral-bg py-[11px] px-[23px] text-white">
      Go to Homepage →
    </a>
  </div>
</div>
@endsection
