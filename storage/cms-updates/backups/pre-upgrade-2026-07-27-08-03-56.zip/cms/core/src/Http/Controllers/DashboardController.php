<?php

namespace Cms\Core\Http\Controllers;

use Illuminate\Routing\Controller;

class DashboardController extends Controller
{
    /**
     * Show the CMS dashboard.
     */
    public function index()
    {
        return view('cms-core::dashboard.index');
    }
}
